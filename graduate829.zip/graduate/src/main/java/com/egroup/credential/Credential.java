package com.egroup.credential;

public class Credential {
	protected static String LOCAL_USER = "egroup";
	protected static String PROJECTPATH = "D:/github/webAutoGenerator_backend/model";
}
